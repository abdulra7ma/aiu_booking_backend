#!/bin/sh

docker-compose --file docker-compose-server.yml --project-name=aiu_booking up --build -d
docker-compose --file docker-compose-server.yml run --user root app ./app/manage.py migrate
docker-compose --file docker-compose-server.yml run --user root app ./app/manage.py collectstatic --no-input
