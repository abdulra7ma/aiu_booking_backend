from django.contrib import admin
from aiu_booking.apps.booking.models import Facility, Booking

admin.site.register(Facility)
admin.site.register(Booking)
