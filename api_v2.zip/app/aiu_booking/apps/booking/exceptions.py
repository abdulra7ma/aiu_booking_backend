from django.core.exceptions import ValidationError


class CustomeError(ValidationError):

    pass
