from aiu_booking.apps.booking.utils.swagger._common import get_query_id_param


__all__ = ["facility_id_param"]

facility_id_param = get_query_id_param("Facility id")
