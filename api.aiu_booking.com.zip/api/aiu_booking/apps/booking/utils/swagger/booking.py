from aiu_booking.apps.booking.utils.swagger._common import get_query_id_param


__all__ = ["booking_id_param"]

booking_id_param = get_query_id_param("Booking id")
