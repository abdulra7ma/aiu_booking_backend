from django.apps import AppConfig


class AccountConfig(AppConfig):
    name = "aiu_booking.apps.accounts"
