from aiu_booking.fixtures import *  # noqa: W0401, W0611
