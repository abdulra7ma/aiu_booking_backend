#!/bin/sh

docker-compose --file docker-compose-local.yml --project-name=aiu_booking up --build
