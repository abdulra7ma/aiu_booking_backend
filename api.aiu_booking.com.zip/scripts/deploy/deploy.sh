#!/bin/sh

docker-compose --file docker-compose-server.yml --project-name=aiu_booking up --build -d
docker exec --user root -it aiu_booking_app_1 fab django.migrate
docker exec --user root -it aiu_booking_app_1 fab django.collectstatic
